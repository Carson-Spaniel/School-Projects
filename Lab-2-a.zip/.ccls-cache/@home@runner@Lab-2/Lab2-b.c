#include <stdio.h>

int main()
{

    // Array to hold the monkey data
  //float food[3][5]; // In your case this would be: float food[3][5]
  // You will need to use nested loops to deal with 2D-arrays

   int disp[2][3];
   /*Counter variables for the loop*/
   int i, j;
   for(i=0; i<2; i++) {
      for(j=0;j<3;j++) {
         printf("Enter value for disp[%d][%d]:", i, j);
         scanf("%d", &disp[i][j]);
      }
   }

	return 0;
}

